package com.example.tesing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesingApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesingApplication.class, args);
	}

}
